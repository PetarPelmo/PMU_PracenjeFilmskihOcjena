package com.petar.petarl_pmuv2

data class korisnik(

    var ime: String = "",
    var prezime: String = "",
    var godine: String = "",
    var email: String = "",
    var id: Int = 0
)
