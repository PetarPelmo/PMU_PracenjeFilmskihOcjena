package com.petar.petarl_pmuv2

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.petar.petarl_pmuv2.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    lateinit var binding: ActivityMainBinding
    private val database: DatabaseReference =
        FirebaseDatabase.getInstance("https://fir-pmu-default-rtdb.europe-west1.firebasedatabase.app/").getReference("tekstovi")

    var list = ArrayList<korisnik>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.commit.setOnClickListener {

            val ime = binding.ime.text.toString()
            val prezime = binding.prezime.toString()
            val godine = binding.godine.toString()
            val email = binding.email.toString()

            var id = 0
            if (!list.isEmpty())
                id = list[list.size - 1].id + 1

            list.add(korisnik(ime, prezime, godine, email, id))

            database.addValueEventListener(object : ValueEventListener {

                override fun onDataChange(snapshot: DataSnapshot) {
                    list.clear()

                    try {

                        val a: List<korisnik> = snapshot.children.map { dataSnapshot -> dataSnapshot.getValue(korisnik::class.java)!!   }
                        list.addAll(a)

                    } catch (_: Exception) {
                    }


                    binding.recycler.apply {

                        layoutManager =
                            LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)
                        adapter = korisnik_adapter(list, this@MainActivity)

                    }

                }

                override fun onCancelled(error: DatabaseError) {
                    TODO("Not yet implemented")
                }
            })

        }


    }
}