package com.petar.petarl_pmuv2

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.petar.petarl_pmuv2.databinding.AutentikacijaBinding


class Authentication : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var binding: AutentikacijaBinding

    private val database2: DatabaseReference = FirebaseDatabase.getInstance("https://fir-pmu-default-rtdb.europe-west1.firebasedatabase.app/").getReference("User")
    private val database3: DatabaseReference = FirebaseDatabase.getInstance("https://fir-pmu-default-rtdb.europe-west1.firebasedatabase.app/").getReference("UsersLeaderboard")

    private var userId: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = AutentikacijaBinding.inflate(layoutInflater)
        setContentView(binding.root)

        auth = FirebaseAuth.getInstance()

        val currentUser = auth.currentUser
        if(currentUser != null){

            userId = currentUser.uid
            val intent = Intent(this, Menu::class.java)
            intent.putExtra("user", currentUser)
            startActivity(intent)
        }

        binding.login.setOnClickListener{

            if (binding.email.text.toString().isEmpty()) Toast.makeText(applicationContext, getString(R.string.unesi_ime), Toast.LENGTH_SHORT).show()
            else if (binding.password.text.toString().isEmpty()) Toast.makeText(applicationContext, getString(R.string.unesi_lozinku), Toast.LENGTH_SHORT).show()
            else if (binding.password.text.toString().length < 8) Toast.makeText(applicationContext, getString(R.string.pass_kratak), Toast.LENGTH_SHORT).show()

            else{

                val str = binding.email.text.toString().filter { !it.isWhitespace() }
                val email = "$str@gmail.com"
                val password = binding.password.text.toString()
                auth.signInWithEmailAndPassword(email, password)
                    .addOnCompleteListener(this) { task ->
                        if (task.isSuccessful){
                            Toast.makeText(baseContext, getString(R.string.uspjesna_prijava), Toast.LENGTH_SHORT).show()

                            val user = auth.currentUser
                            val intent = Intent(this, Menu::class.java)
                            intent.putExtra("user", user)
                            startActivity(intent)
                        }

                        else {
                            Toast.makeText(baseContext, getString(R.string.neuspjesna_prijava), Toast.LENGTH_SHORT).show()
                        }
                    }
            }
        }




        binding.register.setOnClickListener{

            if (binding.email.text.toString().isEmpty()) Toast.makeText(applicationContext, getString(R.string.unesi_ime), Toast.LENGTH_SHORT).show()
            else if (binding.password.text.toString().isEmpty()) Toast.makeText(applicationContext, getString(R.string.unesi_lozinku), Toast.LENGTH_SHORT).show()
            else if (binding.password.text.toString().length < 8) Toast.makeText(applicationContext, getString(R.string.pass_kratak), Toast.LENGTH_SHORT).show()


            val str = binding.email.text.toString().filter { !it.isWhitespace() }
            val email = "$str@gmail.com"
            val password = binding.password.text.toString()

            auth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this) { task ->
                    if (task.isSuccessful){
                        Toast.makeText(baseContext, getString(R.string.uspjesna_registracija), Toast.LENGTH_SHORT).show()

                        val user = auth.currentUser
                        userId = user!!.uid
                        val currentUserDb = database2.child(userId)
                    }

                    else {
                        Toast.makeText(baseContext, getString(R.string.neuspjesna_registracija), Toast.LENGTH_SHORT).show()
                    }

        }

        }

        }
}