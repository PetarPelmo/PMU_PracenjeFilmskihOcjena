package com.petar.petarl_pmuv2

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.petarl_pmuv2.databinding.ItemKorisnikAdapter


class korisnik_adapter(

    val list: ArrayList<korisnik>,
    val th: Context

): RecyclerView.Adapter<korisnik_adapter.ViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = ItemKorisnikAdapter.inflate(LayoutInflater.from(th),parent, false)
        return ViewHolder(v)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bindItem(list[position], th)
    }

    override fun getItemCount(): Int {
        return list.size
    }

    class ViewHolder(private var itemBinding: ItemKorisnikAdapter):
        RecyclerView.ViewHolder(itemBinding.root){
        fun bindItem(tekst:korisnik, th:Context){
            itemBinding.ime.text = tekst.ime
            itemBinding.prezime.text = tekst.prezime
            itemBinding.godine.text = tekst.godine
            itemBinding.radniPolozaj.text = tekst.radniPolozaj
            itemBinding.id.text = tekst.id.toString()
        }
    }
}
