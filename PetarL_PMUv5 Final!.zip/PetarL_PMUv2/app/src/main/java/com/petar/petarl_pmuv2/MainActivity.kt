package com.petar.petarl_pmuv2

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.petar.petarl_pmuv2.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    lateinit var binding: ActivityMainBinding
    private val database: DatabaseReference =
        FirebaseDatabase.getInstance("https://fir-pmu-default-rtdb.europe-west1.firebasedatabase.app/").getReference("tekstovi")

    var list = ArrayList<film>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.Unesi.setOnClickListener {

            val ime = binding.ime.text.toString()
            val godina = binding.godina.toString()
            val boxOffice = binding.BoxOffice.toString()
            var id = 0
            if (!list.isEmpty())
                id = list[list.size - 1].ID + 1
            list.add(film(ime, godina, boxOffice, id))

            database.addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    list.clear()
                    try {
                        val a: List<film> = snapshot.children.map { dataSnapshot -> dataSnapshot.getValue(film::class.java)!!   }
                        list.addAll(a)
                    } catch (e: Exception) {
                        println(e.toString())
                    }
                    binding.recycler.apply {
                        layoutManager =
                            LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)
                        adapter = film_adapter(list, this@MainActivity)
                    }
                }
                override fun onCancelled(error: DatabaseError) {
                    println(error.toString())
                }
            })
        }
    }
}