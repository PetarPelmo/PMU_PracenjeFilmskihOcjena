package com.petar.petarl_pmuv2

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.petar.petarl_pmuv2.databinding.FilmBinding


class film_adapter(

    val list: ArrayList<film>,
    val th: Context

): RecyclerView.Adapter<film_adapter.ViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = FilmBinding.inflate(LayoutInflater.from(th),parent,false)
        return ViewHolder(v)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bindItem(list[position], th)
    }

    override fun getItemCount(): Int {
        return list.size
    }

    class ViewHolder(private var itemBinding: FilmBinding):
        RecyclerView.ViewHolder(itemBinding.root){
        fun bindItem(tekst:film, th:Context){
            itemBinding.ime.text = tekst.ime
            itemBinding.godina.text = tekst.godina
            itemBinding.id.text = tekst.ID.toString()
        }
    }
}