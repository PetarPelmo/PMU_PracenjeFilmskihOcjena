package com.petar.petarl_pmuv2

data class ocjena(
    var korisnik: korisnik,
    var Ocjena: Int,
    var film: film
)
