package com.petar.petarl_pmuv2

data class film(
    var ime: String = "",
    var godina: String = "",
    var boxOffice: String = "",
    var ID: Int = 0,
    )
