package com.petar.petarl_pmuv2

data class korisnik(
    var Username: String,
    var email: String,
    var Film: film
)
