package com.Petar.firebasepl


data class Korisnik(
    var id: Int=0,
    var ime: String="",
    var prezime: String="",
    var god : String=""
)