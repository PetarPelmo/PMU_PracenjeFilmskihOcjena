package com.Petar.firebasepl

data class tekst(val tempId: Int, val tempOpis: String, val tempText: String) {
    var id:Int=0
    var opis:String=""
    var text:String=""
}