package com.Petar.firebasepl

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.Petar.firebasepl.databinding.TekstItemBinding

class textAdapter(
    private val textlist:ArrayList<tekst>,
    private val th:Context

): RecyclerView.Adapter<textAdapter.ViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = TekstItemBinding.inflate(LayoutInflater.from(th),parent,  false)
        return ViewHolder(v)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bindItem(textlist[position])
    }

    override fun getItemCount(): Int {
        return textlist.size
    }

    class ViewHolder(private val itemBinding: TekstItemBinding)  :
            RecyclerView.ViewHolder(itemBinding.root){
                fun bindItem(tekst: tekst){
                    itemBinding.id.text=tekst.id.toString()
                    itemBinding.tekst.text=tekst.text
                    itemBinding.opis.text=tekst.opis
                }
            }
}