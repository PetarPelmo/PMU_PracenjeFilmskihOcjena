package com.petar.petarl_pmuv2
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase

class ProfileActivity : AppCompatActivity() {

    private lateinit var editTextName: EditText
    private lateinit var editTextEmail: EditText
    private lateinit var editTextNewPassword: EditText
    private lateinit var buttonSave: Button

    private lateinit var firebaseAuth: FirebaseAuth
    private lateinit var database: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        editTextName = findViewById(R.id.editTextName)
        editTextEmail = findViewById(R.id.editTextEmail)
        editTextNewPassword = findViewById(R.id.editTextNewPassword)
        buttonSave = findViewById(R.id.buttonSave)

        firebaseAuth = Firebase.auth
        database = Firebase.database.reference

        val currentUser = firebaseAuth.currentUser
        val userId = currentUser?.uid

        userId?.let {
            database.child("users").child(it).get().addOnSuccessListener { dataSnapshot ->
                if (dataSnapshot.exists()) {
                    val user = dataSnapshot.getValue(korisnik::class.java)
                    user?.let { user ->
                        editTextName.setText(user.ime)
                        editTextEmail.setText(user.)
                    }
                }
            }.addOnFailureListener {
            }
        }

        buttonSave.setOnClickListener {
            val name = editTextName.text.toString().trim()
            val email = editTextEmail.text.toString().trim()
            val newPassword = editTextNewPassword.text.toString().trim()

            val userMap = hashMapOf(
                "name" to name,
                "email" to email
            )

            userId?.let {
                database.child("users").child(it).updateChildren(userMap)
                    .addOnSuccessListener {
                    }
                    .addOnFailureListener { exception ->
                    }
            }

            if (newPassword.isNotEmpty()) {
                currentUser?.updatePassword(newPassword)
                    ?.addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                        } else {
                        }
                    }
            }
        }
    }
}
